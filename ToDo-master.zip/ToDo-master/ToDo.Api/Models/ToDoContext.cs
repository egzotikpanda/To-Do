﻿using Microsoft.EntityFrameworkCore;

namespace ToDo.Api.Models
{
    public class ToDoContext : DbContext
    {
        public ToDoContext(DbContextOptions<ToDoContext> options) : base(options)
        {
        }

        public DbSet<ToDoItem> ToDoItems { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<ToDoItem>().HasData(
                new ToDoItem 
                { 
                    Id = 1,
                    Name = "To do item 1",
                    IsComplete = false
                },
                new ToDoItem
                {
                    Id = 2,
                    Name = "To do item 2",
                    IsComplete = false
                },
                new ToDoItem
                {
                    Id = 3,
                    Name = "To do item 3",
                    IsComplete = false
                },
                new ToDoItem
                {
                    Id = 4,
                    Name = "To do item 4",
                    IsComplete = false
                },
                new ToDoItem
                {
                    Id = 5,
                    Name = "To do item 5",
                    IsComplete = false
                },
                new ToDoItem
                {
                    Id = 6,
                    Name = "To do item 6",
                    IsComplete = false
                },
                new ToDoItem
                {
                    Id = 7,
                    Name = "To do item 7",
                    IsComplete = false
                },
                new ToDoItem
                {
                    Id = 8,
                    Name = "To do item 8",
                    IsComplete = false
                },
                new ToDoItem
                {
                    Id = 9,
                    Name = "To do item 9",
                    IsComplete = false
                },
                new ToDoItem
                {
                    Id = 10,
                    Name = "To do item 10",
                    IsComplete = false
                });
        }
    }
}
